﻿// pract_2.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
//Структуры
struct Rectangle {
	double width;
	double height;
};
class BankAccount {
private:
	char accountNumber[50];
	double balance=0.0;

public:
	void popoln(double p) //пополнение
	{
		balance += p;
		std::cout << "Пополнено: " << p << ". Ваш баланс: " << balance << std::endl;
	}
	void snat(double s) //снятие
	{
		balance -= s;
		std::cout << "Снято: " << s << ". Ваш баланс: " << balance << std::endl;
	}
};


int main()
{
	setlocale(LC_ALL, "Russian");
	//Одномерный массив
	/*int array[10] = { -2,3,5,-8,7,10,-22,9,2,13 };
	int count = 0;
	int max = 0;
	for (int i = 0;i < 10;i++)
	{
		if (array[i] > max)
		{
			max =array[i];
		}
	}
	std::cout << "Максимальный элемент в одномерном массиве:" << max << std::endl;*/

	//Многомерные массивы
	/*int array[3][3];
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			std::cout << "Элемент [" << i << "][" << j << "]: ";
			std::cin >> array[i][j];
		}

	}
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			if (array[i][j] != array[j][i]) {
				std::cout << "Массив не симетричен";
				return false;
			}
			
		}
		std::cout << "Массив симетричен";
		return true;
	}*/
	


	//Структуры
	/*Rectangle rec;
	std::cout << "Введите ширину прямоугольника:";
	std::cin >> rec.width;
	std::cout << "Введите высоту прямоугольника:";
	std::cin >> rec.height;
	double rezult = rec.width * rec.height;
	std::cout << "Площадь прямоугольника: " << rezult << std::endl;*/

	//Классы
	/*BankAccount bank;
	double p, s;
	std::cout << "Введите сколько вы ходите положить на счет:" << std::endl;
	std::cin >> p;;
	bank.popoln(p);
	std::cout << "Введите сколько вы хотите снять со счета:" << std::endl;
	std::cin >> s;;
	bank.snat(s);*/

}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
